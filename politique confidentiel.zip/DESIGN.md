---
name: Artisanal Tearoom & Cultural Bakery
colors:
  surface: '#fff8f3'
  surface-dim: '#e7d8c4'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff2e2'
  surface-container: '#fcebd7'
  surface-container-high: '#f6e6d2'
  surface-container-highest: '#f0e0cc'
  on-surface: '#221a0e'
  on-surface-variant: '#574140'
  inverse-surface: '#382f22'
  inverse-on-surface: '#ffeeda'
  outline: '#8a7170'
  outline-variant: '#debfbe'
  surface-tint: '#a73739'
  primary: '#500009'
  on-primary: '#ffffff'
  primary-container: '#731018'
  on-primary-container: '#ff7977'
  inverse-primary: '#ffb3b0'
  secondary: '#8e4e0e'
  on-secondary: '#ffffff'
  secondary-container: '#ffab66'
  on-secondary-container: '#773e00'
  tertiary: '#411700'
  on-tertiary: '#ffffff'
  tertiary-container: '#632700'
  on-tertiary-container: '#ee8951'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad8'
  primary-fixed-dim: '#ffb3b0'
  on-primary-fixed: '#410006'
  on-primary-fixed-variant: '#861f24'
  secondary-fixed: '#ffdcc3'
  secondary-fixed-dim: '#ffb77e'
  on-secondary-fixed: '#2f1500'
  on-secondary-fixed-variant: '#6e3900'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#793100'
  background: '#fff8f3'
  on-background: '#221a0e'
  surface-variant: '#f0e0cc'
typography:
  display:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.01em
  display-mobile:
    fontFamily: Playfair Display
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  price-tag:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 26px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 2rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design narrative is anchored in hospitality, kinship, and cross-cultural warmth. Drawing directly from the philosophy *"Un thé, mille cultures, une seule famille"*, the visual style balances traditional artisanal craftsmanship with an inclusive, approachable community space. The ambiance is that of a bustling, fragrant salon de thé: steaming porcelain cups, terracotta tiles, spice jars, and warm pastry displays.

The aesthetic fuses **Tactile / Warm Editorial** with **Soft Artisanal Modernism**:
- **Warmth & Welcoming Texture:** Generous cream surfaces (`#F2E2CE`) replace cold digital whites, instilling a soothing parchment feel.
- **Generosity & Accessible Luxury:** Rich, comforting undertones (deep wine and baked caramel) reflect artisanal depth without feeling intimidating or exclusive. Prices remain gentle (all under 5€), and the UI echoes this humility with honest, human-centered clarity.
- **Cultural Tapestry:** Subtle decorative motifs, curved arched containers, and warm organic framing evoke the shared ritual of tea across Paris, North Africa, East Asia, and the Levant.

## Colors

The palette is derived directly from steeped tea leaves, spun sugar, and roasted spices:

- **Primary (`#731018`):** Deep Crimson / Bordeaux. Used for primary brand markers, active navigation highlights, primary CTAs, high-level headers, and key accents.
- **Deep Maroon Accent (`#400B06`):** The darkest grounding shade. Reserved for high-contrast typographic hierarchy, deep footers, hero text, and grounding structural outlines.
- **Secondary (`#D98B48`):** Warm Caramel Honey. Illuminates badges, price highlights (e.g., "3,50 €"), subtle button states, and decorative flourishes.
- **Tertiary (`#BF6430`):** Toasted Ochre / Terracotta. Bridges the bordeaux and caramel tones for secondary buttons, seasonal tags, hover states, and warm iconography.
- **Neutral Canvas (`#F2E2CE`):** Soft Steamed Milk / Crème. Acts as the primary surface background, bringing comfort and warmth while eliminating clinical glare.
- **Supporting Surface Tone (`#FAF4EC`):** A lighter cream tint for inner cards and floating dialogs to maintain readable, elevated surfaces against the neutral foundation.

## Typography

The typographic pairing contrasts literary elegance with friendly modern clarity:

- **Headlines (`Playfair Display`):** Brings artisanal craftsmanship, warmth, and a bistro/salon editorial elegance. Headlines feel crafted and historic, conveying the rich cultural origins of teas and pastries.
- **Body & Functional UI (`Plus Jakarta Sans`):** Warm, geometric, and welcoming with slightly rounded terminal strokes. Ensures peak legibility on mobile screens for ingredients, provenance notes, allergies, and checkout steps.
- **Prices (`price-tag`):** Rendered in `Playfair Display` bold, placing focus on accessible indulgence (e.g. *3,80 €*, *2,50 €*), framed in caramel or bordeaux tones.

## Layout & Spacing

The layout uses a responsive fluid grid system designed for effortless culinary browsing across devices:

- **Mobile (< 768px):** 4 columns with `margin` of `1rem` and `gutter` of `1rem`. Products display in single-column narrative cards or two-column compact discovery grids.
- **Tablet (768px – 1024px):** 8 columns with `margin-md` of `2rem` and `gutter-md` of `1.5rem`. Menu categories display as scrollable tab strips with 2-column or 3-column product cards.
- **Desktop (> 1024px):** 12 columns with max container width of `1240px`, `margin-lg` of `3rem`, and `gutter-lg` of `2rem`. Multi-column layouts allow side-by-side tea rituals, origin mapping, and artisanal pastry selections.

Spacing follows an organic 4px/8px rhythm. Generous vertical padding (`space-xl`) between sections creates a calm, unhurried reading pace akin to an afternoon tea break.

## Elevation & Depth

Visual depth avoids stark digital drop shadows, instead utilizing layered warmth and tactile ambient glows:

- **Tonal Layering:** The primary canvas sits on `#F2E2CE`. Product cards and surfaces elevate by sitting on tinted ivory parchment (`#FAF4EC`), framed by ultra-fine hairline borders (`1px solid rgba(115, 16, 24, 0.12)`).
- **Spiced Ambient Shadows:** Floating elements (sticky order bar, modal popups, active cards) use diffused, warm-tinted shadows:
  - *Resting Card:* `0 2px 8px rgba(64, 11, 6, 0.05)`
  - *Hovered / Interactive Card:* `0 8px 24px rgba(64, 11, 6, 0.10)`
  - *Floating Menu / Drawer:* `0 12px 36px rgba(64, 11, 6, 0.16)`
- **Embossed Accents:** Price pills and category tags use soft tone-on-tone backings with subtle 1px border contrast, maintaining a hand-pressed paper feel.

## Shapes

The shape system adopts a **Rounded (Level 2)** language with custom arched details:
- **Base Components (Inputs, Buttons, Badges):** Standard `0.5rem` (`rounded`) to `1rem` (`rounded-lg`) radius, mimicking teacup handles, glazed earthenware, and smooth pastry lines.
- **Cards & Modals:** `rounded-lg` (`1rem`) to `rounded-xl` (`1.5rem`), softening the frame and welcoming casual touch interactions.
- **Cultural Arch Metaphor:** Hero imagery, tea feature cards, and menu category banners optionally employ an arched top border (`border-radius: 2rem 2rem 0.5rem 0.5rem`), echoing traditional teahouse archways and Moroccan/Levantine salon architecture.

## Components

### Buttons
- **Primary Button:** Filled deep bordeaux (`#731018`) with cream text (`#F2E2CE`), height 44px (mobile 48px), `rounded-lg`, subtle hover glow shifting toward `#400B06`.
- **Secondary Button:** Warm caramel border (`#BF6430`) with rich maroon text (`#400B06`) and translucent background (`rgba(217, 139, 72, 0.08)`).
- **Affordable Add CTA:** A compact round pill button (`+ Ajouter - 3,50 €`) with high tactile contrast.

### Chips & Cultural Origin Tags
- Used for tea origins (*"Menthe Marocaine"*, *"Chai Épicé"*, *"Sencha Kyoto"*, *"Fleur d'Oranger"*), sweetness levels, and dietary tags (*"Sans Gluten"*, *"Artisanal"*).
- Background: Soft cream tint with a `1px` stroke in `#D98B48`. Font: `label-md` in `#731018`.

### Product & Pastry Cards
- Background `#FAF4EC` on the `#F2E2CE` canvas.
- Features warm imagery with rounded corners, origin badge top-left, price badge top-right in caramel ribbon, item name in `headline-sm` (`Playfair Display`), and sweet tasting notes in `body-sm`.
- Prominently showcases the sub-5€ accessible price tag in bold styling.

### Input Fields & Selectors
- Background: Pure cream (`#FAF4EC`) with a `1px` border of `rgba(115, 16, 24, 0.25)`.
- Focus state: Border turns to solid `#731018` with an ambient glow of `0 0 0 3px rgba(217, 139, 72, 0.25)`.
- Floating labels in `Plus Jakarta Sans`, text in `#400B06`.

### Checkboxes & Radios
- Rounded `4px` (checkbox) or circular (radio) with `#BF6430` border.
- Selected state fills with `#731018` featuring a warm cream checkmark.

### Steeping Timer & Infusion Guide
- An exclusive component for the tearoom experience: a circular dial showing brewing temperature (e.g. *85°C*) and recommended infusion time (*3 min*), framed in caramel and bordeaux ring accents.